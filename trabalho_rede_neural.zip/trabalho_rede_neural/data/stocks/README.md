# Dados Históricos de Ações

Este diretório contém dados históricos de ações brasileiras para uso offline.

## Estrutura

Os dados são organizados em subdiretórios por ticker:

- `/VIVA3_SA/` - Dados da Vivara
- `/MOVI3_SA/` - Dados da Movida
- `/TRIS3_SA/` - Dados da Trisul

## Formato dos Arquivos

Cada ticker contém arquivos nos seguintes formatos:

- `historical_XYZd.parquet` - Arquivo otimizado para leitura rápida pelo sistema
- `historical_XYZd.csv` - Arquivo CSV para fácil visualização manual

Onde `XYZ` é o número de dias (ex: 1825 para 5 anos).

## Atualização de Dados

Os dados são automaticamente atualizados quando:

1. O modo offline não está ativado
2. Os dados em cache têm mais de 24 horas
3. O usuário clica no botão "Atualizar Análise"

## Uso Manual

Para baixar manualmente todos os dados atualizados, você pode executar:

```python
from src.data_collector import DataCollector

collector = DataCollector()
results = collector.download_all_stocks_data(force_update=True)
print(results)
