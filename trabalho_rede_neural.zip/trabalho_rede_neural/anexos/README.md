# Sistema de Previsão de Ações Brasileiras

## Visão geral

Este é um sistema abrangente de previsão de ações brasileiras (VIVA3, MOVI3, TRIS3) construído com Streamlit e alimentado por redes neurais LSTM. O aplicativo combina análise técnica com aprendizado de máquina para fornecer previsões de preços e recomendações de negociação.

## Preferências do usuário

Estilo de comunicação preferido: linguagem simples e cotidiana.

## Arquitetura do sistema

### Arquitetura front-end
- **Estrutura**: aplicativo web Streamlit
- **Componentes da interface do usuário**: barra lateral interativa para configuração, painel principal com gráficos e previsões
- **Visualização**: Plotly para gráficos interativos, incluindo padrões de velas, indicadores técnicos e visualizações de previsões
- **Layout**: layout amplo com barra lateral expansível para uma melhor experiência do usuário

### Arquitetura back-end
- **Motor central**: arquitetura Python modular com classes especializadas
- **Modelo de previsão**: redes neurais LSTM (Long Short-Term Memory) usando TensorFlow/Keras
- **Análise técnica**: indicadores técnicos abrangentes usando a biblioteca TALib
- **Processamento de dados**: Pandas e NumPy para manipulação e análise de dados

### Camada de dados
- **Fonte de dados**: API do Yahoo Finance via biblioteca yfinance
- **Armazenamento de dados**: processamento em memória com Pandas DataFrames
- **Processamento de dados**: Coleta de dados em tempo real e pipelines de pré-processamento

## Componentes principais

### 1. Coleta de dados (`src/data_collector.py`)
- **Objetivo**: Busca dados históricos de ações no Yahoo Finance
- **Recursos**:
- Períodos de tempo configuráveis (1 a 5 anos)
- Limpeza e validação de dados
- Cálculos de colunas derivadas
- **Ações suportadas**: VIVA3.SA, MOVI3.SA, TRIS3.SA

### 2. Modelo LSTM (`src/lstm_model.py`)
- **Objetivo**: Modelo de aprendizado profundo para previsão de preços
- **Arquitetura**: 
  - Camadas LSTM sequenciais com dropout para regularização
  - Normalização em lote para treinamento estável
  - Otimizador Adam com programação da taxa de aprendizagem
- **Recursos**: Entrada multifuncional (dados OHLCV), parada antecipada, previsão baseada em sequência

### 3. Análise técnica (`src/technical_analysis.py`)
- **Objetivo**: Cálculos abrangentes de indicadores técnicos
- **Indicadores**:
- Médias móveis (SMA, EMA)
- Osciladores (RSI, estocástico)
  - Bandas de Bollinger
  - MACD
  - Indicadores de volume
  - Níveis de suporte/resistência
  - Padrões de velas

### 4. Mecanismo de previsão (`src/prediction_engine.py`)
- **Objetivo**: Orquestra previsões e gera recomendações
- **Recursos**: 
  - Previsões de múltiplos horizontes temporais
  - Pontuação de confiança
  - Análise de risco
  - Recomendações de negociação

### 5. Visualizações (`src/visualizations.py`)
- **Objetivo**: Geração de gráficos interativos
- **Gráficos**: 
  - Candlestick com sobreposições técnicas
  - Análise de volume
  - Subgráficos de indicadores
  - Visualizações de previsões

### 6. Utilitários (`src/utils.py`)
- **Objetivo**: Métricas de risco financeiro e funções auxiliares
- **Métricas**: 
  - Valor em risco (VaR)
  - Índice de Sharpe
  - Drawdown máximo
  - Cálculos de volatilidade

## Fluxo de dados

1. **Ingestão de dados**: Dados históricos de ações obtidos da API do Yahoo Finance
2. **Pré-processamento de dados**: Limpeza, normalização e engenharia de recursos
3. **Análise técnica**: Cálculo de vários indicadores técnicos
4. **Treinamento do modelo**: modelo LSTM treinado em dados históricos processados
5. **Geração de previsões**: previsões de preços prospectivas com intervalos de confiança
6. **Visualização**: gráficos e painéis interativos apresentados ao usuário
7. **Recomendação**: sinais de negociação e avaliações de risco gerados

## Dependências externas

### Bibliotecas principais
- **streamlit**: estrutura de aplicativos da Web
- **yfinance**: API de dados do Yahoo Finance
- **tensorflow**: estrutura de aprendizado profundo para modelos LSTM
- **scikit-learn**: utilitários de aprendizado de máquina e pré-processamento
- **plotly**: biblioteca de visualização interativa
- **talib**: indicadores de análise técnica
- **scipy**: utilitários de computação científica

### Processamento de dados
- **pandas**: manipulação e análise de dados
- **numpy**: computação numérica

### Desenvolvimento
- **uv**: gerenciador de pacotes Python para gerenciamento de dependências



## Estratégia de implantação


### Configuração
- **Ambiente**: canal Nix stable-24_05
- **Pacotes**: Pacotes de sistema otimizados, incluindo suporte a localização e bibliotecas de computação científica
- **Fluxo de trabalho**: Instalação automatizada de dependências e inicialização do aplicativo

### Considerações sobre escalabilidade
- **Memória**: Modelos LSTM e dados históricos exigem RAM significativa
- **CPU**: O treinamento do modelo e os cálculos de previsão são intensivos em CPU
- **Armazenamento**: Requisitos mínimos de armazenamento, pois os dados são buscados em tempo real

O sistema foi projetado para sessões de análise de usuário único, em vez de acesso simultâneo de vários usuários, tornando-o adequado para fins educacionais e de análise de negociação individual.

